using Ora_08.Model;

namespace ProductLogicTests
{
    [TestFixture]
    public class Tests
    {
        private List<Product> productList;

        [SetUp]
        public void Setup()
        {
            // Initialize your list of products here
            productList = new List<Product>
            {
                new Product { Id = 1, Name = "Product 1", Category = "Category A", Price = 100, Stock = 10 },
                new Product { Id = 2, Name = "Product 2", Category = "Category B", Price = 150, Stock = 20 },
                new Product { Id = 3, Name = "Product 3", Category = "Category A", Price = 200, Stock = 0 },
                new Product { Id = 4, Name = "Product 4", Category = "Category C", Price = 80, Stock = 15 },
                new Product { Id = 5, Name = "Product 5", Category = "Category B", Price = 120, Stock = 5 }
            };

            // Mock the repository


            // Initialize the service with the mocked repository

        }

        [Test]
        public void GetProductNames_ShouldReturnAllProductNames_Test()
        {
            // Act
            

            // Assert
        }

        [Test]
        public void FindProductById_ExistingId_ShouldReturnProduct_Test()
        {
            // Arrange
            

            // Act
            

            // Assert
            
        }

        [Test]
        public void FindProductById_NonExistingId_ShouldReturnNull_Test()
        {
            // Act


            // Assert
            
        }

        [Test]
        public void GetProductsInCategory_ValidCategory_ShouldReturnProducts_Test()
        {
            // Arrange
            


            // Act
            

            // Assert
            
        }

        [Test]
        public void GetProductsWithPriceGreaterThan_ShouldReturnProducts_Test()
        {
            // Arrange
            

            // Act
            

            // Assert
            
        }

        [Test]
        public void GetProductsWithPriceLessThan_ShouldReturnProducts_Test()
        {
            // Arrange
            

            // Act
            

            // Assert
            
        }

        [Test]
        public void GetProductsWithMinimumStock_ShouldReturnProducts_Test()
        {
            // Arrange
            

            // Act
            

            // Assert
            
        }

        [Test]
        public void IsProductInStock_InStock_ShouldReturnTrue_Test()
        {
            // Arrange
            

            // Act
            

            // Assert
            
        }

        [Test]
        public void IsProductInStock_OutOfStock_ShouldReturnFalse_Test()
        {
            // Arrange
            

            // Act
            

            // Assert
            
        }
    }
}